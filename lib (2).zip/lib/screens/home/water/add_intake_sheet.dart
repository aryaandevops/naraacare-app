import 'package:flutter/material.dart';
import '../../../core/theme.dart';
import '../../../models/water_log_entry.dart';

/// Bottom sheet matching the final "Add Intake" mockup: Water tab and
/// Other Drinks tab, both sharing a live "Recent Updates" list (last 2
/// entries) that can be edited or deleted inline via the pencil icon.
///
/// Returns the newly logged [WaterLogEntry] via Navigator.pop when the
/// user submits, or null if dismissed without logging anything new.
/// Edits/deletes to existing entries happen immediately through the
/// [onEditEntry] / [onDeleteEntry] callbacks — they don't wait for the
/// sheet to close.
class AddIntakeSheet extends StatefulWidget {
  final List<String> savedCustomDrinks;
  final List<WaterLogEntry> recentEntries; // most recent first, max 2
  final void Function(String id, {required int amountMl, required String label}) onEditEntry;
  final void Function(String id) onDeleteEntry;

  const AddIntakeSheet({
    super.key,
    required this.savedCustomDrinks,
    required this.recentEntries,
    required this.onEditEntry,
    required this.onDeleteEntry,
  });

  static Future<WaterLogEntry?> show(
    BuildContext context, {
    required List<String> savedCustomDrinks,
    required List<WaterLogEntry> recentEntries,
    required void Function(String id, {required int amountMl, required String label}) onEditEntry,
    required void Function(String id) onDeleteEntry,
  }) {
    return showModalBottomSheet<WaterLogEntry>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(sheetContext).viewInsets.bottom,
          ),
          child: AddIntakeSheet(
            savedCustomDrinks: savedCustomDrinks,
            recentEntries: recentEntries,
            onEditEntry: onEditEntry,
            onDeleteEntry: onDeleteEntry,
          ),
        );
      },
    );
  }

  @override
  State<AddIntakeSheet> createState() => _AddIntakeSheetState();
}

class _AddIntakeSheetState extends State<AddIntakeSheet> {
  int _tabIndex = 0; // 0 = Water, 1 = Other Drinks

  // --- Water tab state ---
  final _waterAmountController = TextEditingController(text: '350');

  // --- Other Drinks tab state ---
  String? _selectedPresetDrink;
  bool _showSearch = false;
  final _searchController = TextEditingController();
  final _customDrinkController = TextEditingController();
  final _drinkAmountController = TextEditingController();

  @override
  void dispose() {
    _waterAmountController.dispose();
    _searchController.dispose();
    _customDrinkController.dispose();
    _drinkAmountController.dispose();
    super.dispose();
  }

  int? get _waterAmountMl => int.tryParse(_waterAmountController.text.trim());

  int? get _drinkAmountMl => int.tryParse(_drinkAmountController.text.trim());

  String get _drinkName => _customDrinkController.text.trim();

  List<String> get _drinkOptions {
    final combined = <String>{...kPresetDrinks, ...widget.savedCustomDrinks};
    if (!_showSearch || _searchController.text.trim().isEmpty) return combined.toList();
    final query = _searchController.text.trim().toLowerCase();
    return combined.where((d) => d.toLowerCase().contains(query)).toList();
  }

  DrinkCategory _categoryFor(String name) {
    switch (name) {
      case 'Tea':
        return DrinkCategory.tea;
      case 'Coffee':
        return DrinkCategory.coffee;
      case 'Juice':
        return DrinkCategory.juice;
      case 'Milk':
        return DrinkCategory.milk;
      case 'Beer':
        return DrinkCategory.beer;
      case 'Coconut Water':
        return DrinkCategory.coconutWater;
      default:
        return DrinkCategory.custom;
    }
  }

  void _submitWater() {
    final ml = _waterAmountMl;
    if (ml == null || ml <= 0) return;
    Navigator.of(context).pop(
      WaterLogEntry(
        id: UniqueKey().toString(),
        label: 'Water',
        category: DrinkCategory.water,
        amountMl: ml,
        time: DateTime.now(),
      ),
    );
  }

  void _submitOtherDrink() {
    final ml = _drinkAmountMl;
    final name = _drinkName;
    if (ml == null || ml <= 0 || name.isEmpty) return;
    Navigator.of(context).pop(
      WaterLogEntry(
        id: UniqueKey().toString(),
        label: name,
        category: _categoryFor(name),
        amountMl: ml,
        time: DateTime.now(),
      ),
    );
  }

  Future<void> _editEntry(WaterLogEntry entry) async {
    final amountController = TextEditingController(text: entry.amountMl.toString());
    final labelController = TextEditingController(text: entry.label);
    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Edit entry'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: labelController,
                decoration: const InputDecoration(labelText: 'Drink'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: amountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Amount (ml)'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
    if (result == true) {
      final newAmount = int.tryParse(amountController.text.trim());
      final newLabel = labelController.text.trim();
      if (newAmount != null && newAmount > 0 && newLabel.isNotEmpty) {
        widget.onEditEntry(entry.id, amountMl: newAmount, label: newLabel);
        setState(() {}); // refresh pill display
      }
    }
  }

  String _timeLabel(DateTime time) {
    final hour = time.hour % 12 == 0 ? 12 : time.hour % 12;
    final minute = time.minute.toString().padLeft(2, '0');
    final period = time.hour >= 12 ? 'PM' : 'AM';
    return '$hour:$minute $period';
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                GestureDetector(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.grey.shade400),
                    ),
                    child: const Icon(Icons.close, size: 18),
                  ),
                ),
                const Expanded(
                  child: Text(
                    'Add Intake',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                  ),
                ),
                const SizedBox(width: 32),
              ],
            ),
            const SizedBox(height: 16),

            Row(
              children: [
                _buildTab('Water', 0),
                const SizedBox(width: 24),
                _buildTab('Other Drinks', 1),
              ],
            ),
            const Divider(height: 24),

            Flexible(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (_tabIndex == 0) _buildWaterTab() else _buildOtherDrinksTab(),
                    const SizedBox(height: 24),
                    _buildRecentUpdates(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTab(String label, int index) {
    final isSelected = _tabIndex == index;
    return GestureDetector(
      onTap: () => setState(() => _tabIndex = index),
      child: Column(
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w600,
              color: isSelected ? AppColors.primaryBlue : AppColors.textGrey,
            ),
          ),
          const SizedBox(height: 6),
          Container(
            height: 2,
            width: 60,
            color: isSelected ? AppColors.primaryBlue : Colors.transparent,
          ),
        ],
      ),
    );
  }

  Widget _amountChips(TextEditingController controller) {
    const chipValues = [15, 250, 500, 750];
    const chipLabels = ['+1 sip', '+250 ml', '+500 ml', '+750 ml'];
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: List.generate(chipValues.length, (i) {
        return GestureDetector(
          onTap: () => setState(() => controller.text = chipValues[i].toString()),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.primaryBlue.withValues(alpha: 0.4)),
            ),
            child: Text(
              chipLabels[i],
              style: const TextStyle(color: AppColors.primaryBlue, fontWeight: FontWeight.w600, fontSize: 13),
            ),
          ),
        );
      }),
    );
  }

  Widget _buildWaterTab() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Enter amount of water', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
        const SizedBox(height: 10),
        TextField(
          controller: _waterAmountController,
          keyboardType: TextInputType.number,
          onChanged: (_) => setState(() {}),
          decoration: InputDecoration(
            suffixText: 'ml',
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: Colors.grey.shade300),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: AppColors.primaryBlue),
            ),
          ),
        ),
        const SizedBox(height: 12),
        _amountChips(_waterAmountController),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: (_waterAmountMl ?? 0) > 0 ? _submitWater : null,
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primaryBlue,
            disabledBackgroundColor: AppColors.lightBlue,
            minimumSize: const Size(double.infinity, 52),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
          ),
          child: Text(
            'Add ${_waterAmountMl ?? 0} ml of Water',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
          ),
        ),
      ],
    );
  }

  Widget _buildOtherDrinksTab() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Choose a drink', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
        const SizedBox(height: 10),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            ...kPresetDrinks.map((drink) {
              final isSelected = _selectedPresetDrink == drink;
              return ChoiceChip(
                avatar: Icon(presetDrinkIcon(drink), size: 16,
                    color: isSelected ? AppColors.primaryBlue : AppColors.textGrey),
                label: Text(drink),
                selected: isSelected,
                onSelected: (_) {
                  setState(() {
                    _selectedPresetDrink = drink;
                    _customDrinkController.text = drink;
                  });
                },
                selectedColor: AppColors.lightBlue,
                labelStyle: TextStyle(
                  color: isSelected ? AppColors.primaryBlue : AppColors.textGrey,
                  fontWeight: FontWeight.w600,
                ),
                backgroundColor: Colors.white,
                side: BorderSide(color: Colors.grey.shade300),
              );
            }),
            ChoiceChip(
              avatar: Icon(Icons.search, size: 16, color: _showSearch ? AppColors.primaryBlue : AppColors.textGrey),
              label: const Text('Search'),
              selected: _showSearch,
              onSelected: (val) => setState(() => _showSearch = val),
              selectedColor: AppColors.lightBlue,
              labelStyle: TextStyle(
                color: _showSearch ? AppColors.primaryBlue : AppColors.textGrey,
                fontWeight: FontWeight.w600,
              ),
              backgroundColor: Colors.white,
              side: BorderSide(color: Colors.grey.shade300),
            ),
          ],
        ),
        if (_showSearch) ...[
          const SizedBox(height: 10),
          TextField(
            controller: _searchController,
            onChanged: (_) => setState(() {}),
            decoration: InputDecoration(
              hintText: 'Search saved drinks',
              prefixIcon: const Icon(Icons.search, size: 20),
              contentPadding: const EdgeInsets.symmetric(vertical: 4),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(30),
                borderSide: BorderSide(color: Colors.grey.shade300),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(30),
                borderSide: const BorderSide(color: AppColors.primaryBlue),
              ),
            ),
          ),
          if (_drinkOptions.isNotEmpty) ...[
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: _drinkOptions.map((d) {
                return ActionChip(
                  label: Text(d, style: const TextStyle(fontSize: 12)),
                  onPressed: () => setState(() {
                    _selectedPresetDrink = d;
                    _customDrinkController.text = d;
                    _showSearch = false;
                  }),
                );
              }).toList(),
            ),
          ],
        ],
        const SizedBox(height: 16),
        TextField(
          controller: _customDrinkController,
          onChanged: (_) => setState(() => _selectedPresetDrink = null),
          decoration: InputDecoration(
            hintText: 'Enter drink name',
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: Colors.grey.shade300),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: AppColors.primaryBlue),
            ),
          ),
        ),
        const SizedBox(height: 16),
        const Text('Enter amount of drink', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
        const SizedBox(height: 10),
        TextField(
          controller: _drinkAmountController,
          keyboardType: TextInputType.number,
          onChanged: (_) => setState(() {}),
          decoration: InputDecoration(
            hintText: 'Enter drink amount',
            suffixText: 'ml',
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(color: Colors.grey.shade300),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(color: AppColors.primaryBlue),
            ),
          ),
        ),
        const SizedBox(height: 12),
        _amountChips(_drinkAmountController),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: ((_drinkAmountMl ?? 0) > 0 && _drinkName.isNotEmpty) ? _submitOtherDrink : null,
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primaryBlue,
            disabledBackgroundColor: AppColors.lightBlue,
            minimumSize: const Size(double.infinity, 52),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
          ),
          child: Text(
            'Add ${_drinkAmountMl ?? 0} ml of ${_drinkName.isEmpty ? "Drink" : _drinkName}',
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }

  Widget _buildRecentUpdates() {
    if (widget.recentEntries.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Recent Updates', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        for (final entry in widget.recentEntries) ...[
          Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: Colors.grey.shade300),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${entry.amountMl} ml ${entry.label}',
                        style: TextStyle(color: AppColors.textGrey, fontWeight: FontWeight.w500),
                      ),
                      Text(
                        _timeLabel(entry.time),
                        style: TextStyle(color: AppColors.textGrey.withValues(alpha: 0.7), fontSize: 12),
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: () => _editEntry(entry),
                  child: Icon(Icons.edit_outlined, size: 18, color: AppColors.textGrey),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}
