import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/theme.dart';
import '../home/home_screen.dart';
import '../onboarding/gender_name_screen.dart';
import '../rin_ai/rin_ai_screen.dart';
import 'profile_screen.dart';

class CareCirclesScreen extends StatefulWidget {
  const CareCirclesScreen({super.key});

  @override
  State<CareCirclesScreen> createState() => _CareCirclesScreenState();
}

class _CareCirclesScreenState extends State<CareCirclesScreen> {
  bool _hasUsername = false;
  final List<_Circle> _circles = [
    const _Circle('Best Friends', 3, 0),
    const _Circle('Family', 4, 2),
  ];

  final List<_Person> _profileConnections = [
    const _Person('@aara_sharma', 'Last active today'),
    const _Person('@aara_sharma1', 'Last active yesterday'),
    const _Person('@aara_sharma12', 'Last active 3 days ago'),
    const _Person('@aarasharma.1', 'Last active 1 week ago'),
    const _Person('@aaraaaa123_sharma', 'Last active 1 month ago'),
  ];

  final List<_CircleInvite> _invites = [
    const _CircleInvite('Gym Buddies', 5, 'Sahil'),
  ];

  Future<void> _startCreateCircle() async {
    if (!_hasUsername) {
      final created = await _showUsernameSheet();
      if (!created || !mounted) return;
    }

    if (!mounted) return;
    final circle = await Navigator.push<_Circle>(
      context,
      MaterialPageRoute(
        builder: (_) => CreateCircleScreen(
          existingConnections: _profileConnections,
        ),
      ),
    );

    if (circle != null) {
      setState(() => _circles.add(circle));
    }
  }

  Future<bool> _showUsernameSheet() async {
    final controller = TextEditingController();
    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => SafeArea(
        child: Container(
          padding: EdgeInsets.fromLTRB(20, 12, 20, 26 + MediaQuery.of(context).viewInsets.bottom),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(width: 58, height: 4, decoration: BoxDecoration(color: const Color(0xFFA5ABB0), borderRadius: BorderRadius.circular(20))),
              const SizedBox(height: 16),
              Row(
                children: [
                  _roundIconButton(Icons.close, () => Navigator.pop(context, false)),
                  const Expanded(child: Center(child: Text('Profile Username', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500, color: AppColors.textDark)))),
                  const SizedBox(width: 40),
                ],
              ),
              const SizedBox(height: 26),
              const Text('Create your NaraaCare username', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w500, color: AppColors.primaryBlue)),
              const SizedBox(height: 68),
              TextField(
                controller: controller,
                decoration: _fieldDecoration('Enter username'),
              ),
              const SizedBox(height: 24),
              const Align(
                alignment: Alignment.centerLeft,
                child: Text('Choose carefully. You can change it only once every 3 months.', style: TextStyle(fontSize: 10, color: Color(0xFF6C777D))),
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: 212,
                child: ElevatedButton(
                  onPressed: () {
                    if (controller.text.trim().isEmpty) return;
                    Navigator.pop(context, true);
                  },
                  child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Text('Continue'), SizedBox(width: 12), Icon(Icons.arrow_forward, size: 22)]),
                ),
              ),
              TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Set up later', style: TextStyle(color: Color(0xFF7E8B92), fontSize: 16))),
            ],
          ),
        ),
      ),
    );
    controller.dispose();
    if (result == true) {
      _hasUsername = true;
    }
    return result == true;
  }

  static InputDecoration _fieldDecoration(String hint) => InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Color(0xFF7F96A5), fontSize: 16),
        filled: false,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFF9FB0B8))),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: AppColors.primaryBlue)),
      );

  static Widget _roundIconButton(IconData icon, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: const Color(0xFFD7DDE0))),
          child: Icon(icon, color: const Color(0xFF68777E), size: 23),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 26, 20, 16),
              child: Row(
                children: [
                  const Expanded(child: Text('Your Circles', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w500, color: AppColors.textDark))),
                  GestureDetector(
                    onTap: _startCreateCircle,
                    child: Container(
                      width: 30,
                      height: 30,
                      decoration: const BoxDecoration(shape: BoxShape.circle, border: Border.fromBorderSide(BorderSide(color: AppColors.textDark, width: 2))),
                      child: const Icon(Icons.add, size: 23, color: AppColors.textDark),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 30),
                children: [
                  if (_circles.isEmpty)
                    _createPrompt()
                  else ...[
                    _createPrompt(),
                    const SizedBox(height: 42),
                  ],
                  ..._circles.asMap().entries.map((entry) => Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: _circleCard(entry.value),
                      )),
                  if (_invites.isNotEmpty) ...[
                    const SizedBox(height: 34),
                    Container(
                      padding: const EdgeInsets.fromLTRB(20, 18, 20, 20),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(26),
                        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 18, offset: const Offset(0, 5))],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(children: [const Expanded(child: Text('Invites', style: TextStyle(fontSize: 16, color: Color(0xFF71838C)))), TextButton(onPressed: () {}, child: const Text('View All', style: TextStyle(color: AppColors.primaryBlue, fontSize: 14))) ]),
                          const SizedBox(height: 8),
                          ..._invites.map((invite) => GestureDetector(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CircleInviteScreen(invite: invite))), child: _inviteCard(invite))),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _bottomNav(context),
    );
  }

  Widget _createPrompt() => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: const Color(0xFFF0F5FF), borderRadius: BorderRadius.circular(12)),
        child: Row(
          children: [
            const Icon(Icons.track_changes_outlined, color: Color(0xFF70808A), size: 30),
            const SizedBox(width: 14),
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Create a Care Circle', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: Color(0xFF405149))), SizedBox(height: 5), Text('Invite friends and family to share avatars and support each other', style: TextStyle(fontSize: 15, height: 1.35, color: Color(0xFF55675E)))])),
          ],
        ),
      );

  Widget _circleCard(_Circle circle) => GestureDetector(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CircleDetailScreen(circle: circle))),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 14, offset: const Offset(0, 3))]),
          child: Row(
            children: [
              Container(width: 40, height: 40, decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), gradient: const LinearGradient(colors: [Color(0xFFFFB35B), Color(0xFFB4D957), Color(0xFF33AEEB)], begin: Alignment.topLeft, end: Alignment.bottomRight))),
              const SizedBox(width: 16),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(circle.name, style: const TextStyle(fontSize: 18, color: AppColors.textDark)), const SizedBox(height: 4), Text('${circle.members} members • ${circle.updates == 0 ? 'No new updates' : '${circle.updates} updates today'}', style: const TextStyle(fontSize: 14, color: Color(0xFF7A8A93)))])),
              if (circle.updates > 0) Container(width: 20, height: 20, alignment: Alignment.center, decoration: const BoxDecoration(shape: BoxShape.circle, color: AppColors.primaryBlue), child: Text('${circle.updates}', style: const TextStyle(fontSize: 11, color: Colors.white))),
            ],
          ),
        ),
      );

  Widget _inviteCard(_CircleInvite invite) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 14, offset: const Offset(0, 3))]),
        child: Row(children: [Container(width: 40, height: 40, decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), gradient: const LinearGradient(colors: [Color(0xFFFFB35B), Color(0xFFB4D957), Color(0xFF33AEEB)]))), const SizedBox(width: 16), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(invite.name, style: const TextStyle(fontSize: 18, color: AppColors.textDark)), const SizedBox(height: 4), Text('${invite.members} members • by ${invite.invitedBy}', style: const TextStyle(fontSize: 14, color: Color(0xFF7A8A93))) ]))]),
      );

  Widget _bottomNav(BuildContext context) => Container(
        decoration: BoxDecoration(color: Colors.white, boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.10), blurRadius: 8, offset: const Offset(0, -2))]),
        child: SafeArea(top: false, child: SizedBox(height: 64, child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          _nav(context, Icons.home_outlined, 'Home', false, () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => HomeScreen(name: 'Sahil', gender: Gender.male)))),
          _nav(context, Icons.groups_outlined, 'Care Circle', true, () {}),
          _nav(context, Icons.auto_awesome_outlined, 'Rin AI', false, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RinAiScreen(name: 'Sahil', gender: Gender.male)))),
          _nav(context, Icons.person_outline, 'Profile', false, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileScreen(name: 'Sahil', gender: Gender.male)))),
        ])),
      );

  Widget _nav(BuildContext context, IconData icon, String label, bool selected, VoidCallback onTap) => GestureDetector(onTap: onTap, child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, size: 25, color: selected ? AppColors.primaryBlue : const Color(0xFF4A565C)), const SizedBox(height: 2), Text(label, style: TextStyle(fontSize: 10, color: selected ? AppColors.primaryBlue : const Color(0xFF4A565C)))]));
}

class CreateCircleScreen extends StatefulWidget {
  final List<_Person> existingConnections;
  const CreateCircleScreen({super.key, required this.existingConnections});

  @override
  State<CreateCircleScreen> createState() => _CreateCircleScreenState();
}

class _CreateCircleScreenState extends State<CreateCircleScreen> {
  final _nameController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            _titleBar(context, 'Create a Circle'),
            Expanded(child: ListView(padding: const EdgeInsets.fromLTRB(48, 54, 48, 30), children: [
              Center(child: Container(width: 120, height: 120, decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFFF3F8FF)), child: const Icon(Icons.groups_outlined, size: 82, color: AppColors.primaryBlue))),
              const SizedBox(height: 52),
              const Text('Circle name', style: TextStyle(fontSize: 20, color: AppColors.textDark)),
              const SizedBox(height: 12),
              TextField(controller: _nameController, decoration: const InputDecoration(hintText: 'Enter a care circle name', hintStyle: TextStyle(color: Color(0xFF7F96A5)), enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Color(0xFF9FB0B8)), borderRadius: BorderRadius.all(Radius.circular(12))), focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: AppColors.primaryBlue), borderRadius: BorderRadius.all(Radius.circular(12))), contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 16), fillColor: Colors.white, filled: true)),
              const SizedBox(height: 8),
              const Padding(padding: EdgeInsets.only(left: 2), child: Text('You can change this later', style: TextStyle(fontSize: 12, color: Color(0xFF7F96A5)))),
              const SizedBox(height: 190),
              ElevatedButton(onPressed: _next, child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Text('Add Members'), SizedBox(width: 10), Icon(Icons.arrow_forward)])),
            ])),
          ],
        ),
      ),
      bottomNavigationBar: const _SubpageBottomNav(),
    );
  }

  void _next() async {
    if (_nameController.text.trim().isEmpty) return;
    final members = await Navigator.push<List<_Person>>(context, MaterialPageRoute(builder: (_) => AddMembersScreen(connections: widget.existingConnections)));
    if (!mounted || members == null) return;
    final name = _nameController.text.trim();
    final created = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => ShareWithCircleScreen(circleName: name, members: members)));
    if (!mounted || created != true) return;
    Navigator.pop(context, _Circle(name, members.length + 1, 0));
  }

  Widget _titleBar(BuildContext context, String title) => Padding(padding: const EdgeInsets.fromLTRB(24, 24, 24, 0), child: Row(children: [GestureDetector(onTap: () => Navigator.pop(context), child: const Icon(Icons.arrow_back_ios_new, size: 23)), const Expanded(child: Center(child: Text(title, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w500, color: AppColors.textDark)))), const SizedBox(width: 23)]));

  Widget _bottomNav(BuildContext context) => const SizedBox(height: 64);
}

class AddMembersScreen extends StatefulWidget {
  final List<_Person> connections;
  const AddMembersScreen({super.key, required this.connections});

  @override
  State<AddMembersScreen> createState() => _AddMembersScreenState();
}

class _AddMembersScreenState extends State<AddMembersScreen> {
  int _tab = 0;
  final _search = TextEditingController();
  String _query = '';
  final Set<String> _selected = {};

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  List<_Person> get _filtered => widget.connections.where((p) => _query.isEmpty || p.username.contains(_query.toLowerCase())).toList();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        bottom: false,
        child: Column(children: [
          _titleBar(context, 'Add Members'),
          _tabs(),
          Padding(padding: const EdgeInsets.fromLTRB(29, 42, 29, 0), child: TextField(controller: _search, onChanged: (v) => setState(() => _query = v), decoration: const InputDecoration(hintText: 'Search by username', hintStyle: TextStyle(color: Color(0xFF7F96A5)), prefixIcon: Icon(Icons.search, size: 28, color: Color(0xFF627680)), filled: false, enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(13)), borderSide: BorderSide(color: Color(0xFF9FB0B8))), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(13)), borderSide: BorderSide(color: AppColors.primaryBlue)), contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 15)))),
          const SizedBox(height: 25),
          Expanded(child: _tab == 0 ? _peopleList() : _inviteLink()),
          Padding(padding: const EdgeInsets.fromLTRB(90, 0, 90, 26), child: ElevatedButton(onPressed: _continue, child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Text('Continue'), SizedBox(width: 10), Icon(Icons.arrow_forward)]))),
        ]),
      ),
      bottomNavigationBar: const _SubpageBottomNav(),
    );
  }

  Widget _titleBar(BuildContext context, String title) => Padding(padding: const EdgeInsets.fromLTRB(24, 24, 24, 0), child: Row(children: [GestureDetector(onTap: () => Navigator.pop(context), child: const Icon(Icons.arrow_back_ios_new, size: 23)), const Expanded(child: Center(child: Text(title, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w500, color: AppColors.textDark)))), const SizedBox(width: 23)]));

  Widget _tabs() => SizedBox(height: 60, child: Row(children: [_tabButton('People on NaraaCare', 0), _tabButton('Invite Link', 1)]));
  Widget _tabButton(String label, int index) => Expanded(child: GestureDetector(onTap: () => setState(() => _tab = index), child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [Text(label, style: TextStyle(fontSize: 14, color: _tab == index ? AppColors.primaryBlue : const Color(0xFF6C7E87))), const SizedBox(height: 15), Container(height: 2, color: _tab == index ? AppColors.primaryBlue : const Color(0xFFD8E0E4))])));

  Widget _peopleList() => ListView(padding: const EdgeInsets.fromLTRB(28, 0, 20, 20), children: [const Text('CONNECTED ON NARAACARE', style: TextStyle(fontSize: 13, color: Color(0xFF586A73), fontWeight: FontWeight.w600)), const SizedBox(height: 6), ..._filtered.map(_personRow)]);

  Widget _personRow(_Person p) => Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Row(children: [_avatar(), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(p.username, style: const TextStyle(fontSize: 16, color: AppColors.textDark, fontWeight: FontWeight.w500)), const SizedBox(height: 2), Text(p.activity, style: const TextStyle(fontSize: 12, color: Color(0xFF7C8D95)))])), GestureDetector(onTap: () => setState(() => _selected.contains(p.username) ? _selected.remove(p.username) : _selected.add(p.username)), child: _selected.contains(p.username) ? const Icon(Icons.verified_outlined, color: AppColors.primaryBlue, size: 31) : const Icon(Icons.add_circle_outline, color: Color(0xFF4E5C63), size: 31))]));

  Widget _inviteLink() => Column(children: [const SizedBox(height: 56), Container(width: 98, height: 98, decoration: const BoxDecoration(color: Color(0xFFF1F2F5), shape: BoxShape.circle), child: const Icon(Icons.link, size: 46, color: Color(0xFF52616A))), const SizedBox(height: 82), const Text('Invite people on NaraaCare', style: TextStyle(fontSize: 19, color: AppColors.primaryBlue)), const SizedBox(height: 8), const Padding(padding: EdgeInsets.symmetric(horizontal: 45), child: Text('Share this invite link with someone who isn’t on NaraaCare yet and join your circle.', textAlign: TextAlign.center, style: TextStyle(fontSize: 14, height: 1.45, color: Color(0xFF71838C)))), const SizedBox(height: 34), SizedBox(width: 220, child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF5D707B)), onPressed: () { Clipboard.setData(const ClipboardData(text: 'https://naraacare.app/invite/gym-buddies')); ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Invite link copied'))); }, child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Text('Share Invite Link'), SizedBox(width: 8), Icon(Icons.link, size: 20)])))]);

  void _continue() => Navigator.pop(context, widget.connections.where((p) => _selected.contains(p.username)).toList());
  Widget _avatar() => const CircleAvatar(radius: 22, backgroundColor: Color(0xFFE5E9ED));
}


class ShareWithCircleScreen extends StatefulWidget {
  final String circleName;
  final List<_Person> members;
  const ShareWithCircleScreen({super.key, required this.circleName, required this.members});

  @override
  State<ShareWithCircleScreen> createState() => _ShareWithCircleScreenState();
}

class _ShareWithCircleScreenState extends State<ShareWithCircleScreen> {
  bool hydration = true;
  bool nutrition = true;
  bool sleep = false;

  @override
  Widget build(BuildContext context) {
    final canCreate = hydration || nutrition || sleep;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        bottom: false,
        child: Column(children: [
          Padding(padding: const EdgeInsets.fromLTRB(28, 24, 24, 0), child: Align(alignment: Alignment.centerLeft, child: GestureDetector(onTap: () => Navigator.pop(context), child: const Icon(Icons.arrow_back_ios_new, size: 23, color: AppColors.textDark)))),
          const SizedBox(height: 38),
          Text('Share with ${widget.circleName}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w500, color: Color(0xFF5A6C76))),
          const SizedBox(height: 8),
          const Text('Choose atleast 1 avatar to share with all\nmembers of this circle.', textAlign: TextAlign.center, style: TextStyle(fontSize: 15, height: 1.35, color: Color(0xFF71838C))),
          const SizedBox(height: 34),
          _toggleRow('💧', 'Hydration', hydration, (v) => setState(() => hydration = v)),
          _toggleRow('🍽️', 'Nutrition', nutrition, (v) => setState(() => nutrition = v)),
          Row(children: [const SizedBox(width: 28), const Text('😴', style: TextStyle(fontSize: 24)), const SizedBox(width: 10), const Expanded(child: Text('Sleep', style: TextStyle(fontSize: 20, color: AppColors.textDark))), _starBadge(), const SizedBox(width: 8), Switch(value: sleep, onChanged: (v) => setState(() => sleep = v), activeColor: Colors.white, activeTrackColor: AppColors.primaryBlue, inactiveThumbColor: Colors.white, inactiveTrackColor: Color(0xFFE1E5E9)), const SizedBox(width: 22)]),
          const SizedBox(height: 18),
          Container(margin: const EdgeInsets.symmetric(horizontal: 28), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: const Color(0xFFF8F1FF), border: Border.all(color: const Color(0xFFDCC4FF), style: BorderStyle.solid), borderRadius: BorderRadius.circular(12)), child: Row(children: [const Icon(Icons.star, color: Color(0xFF6A4EB0)), const SizedBox(width: 12), const Expanded(child: Text('Why STAR?\nSTAR members can share and view sleep insights with their care circles.', style: TextStyle(fontSize: 14, height: 1.4, color: Color(0xFF5D5168)))), TextButton(onPressed: () {}, child: const Text('Upgrade', style: TextStyle(color: Color(0xFF6A4EB0))))])),
          const SizedBox(height: 10),
          Container(margin: const EdgeInsets.symmetric(horizontal: 28), padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12), decoration: BoxDecoration(color: const Color(0xFFEFF4FF), borderRadius: BorderRadius.circular(12)), child: const Row(children: [Icon(Icons.info_outline, color: Color(0xFF5368F5), size: 20), SizedBox(width: 10), Expanded(child: Text('You can change these anytime from the circle Settings.', style: TextStyle(fontSize: 14, color: Color(0xFF55645F)))])),
          const Spacer(),
          SizedBox(width: 212, child: ElevatedButton(onPressed: canCreate ? () => Navigator.pop(context, true) : null, child: const Text('Create Circle'))),
          const SizedBox(height: 24),
        ]),
      ),
      bottomNavigationBar: const _SubpageBottomNav(),
    );
  }

  Widget _toggleRow(String emoji, String label, bool value, ValueChanged<bool> onChanged) => Row(children: [const SizedBox(width: 28), Text(emoji, style: const TextStyle(fontSize: 24)), const SizedBox(width: 10), Expanded(child: Text(label, style: const TextStyle(fontSize: 20, color: AppColors.textDark))), Switch(value: value, onChanged: onChanged, activeColor: Colors.white, activeTrackColor: AppColors.primaryBlue, inactiveThumbColor: Colors.white, inactiveTrackColor: Color(0xFFE1E5E9)), const SizedBox(width: 22)]);
  Widget _starBadge() => Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: const Color(0xFFF3E6FF), border: Border.all(color: const Color(0xFF8B5CF6)), borderRadius: BorderRadius.circular(5)), child: const Text('🔒STAR', style: TextStyle(fontSize: 10, color: Color(0xFF7C3AED))));
}

class CircleDetailScreen extends StatelessWidget {
  final _Circle circle;
  const CircleDetailScreen({super.key, required this.circle});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(bottom: false, child: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(20, 24, 20, 12), child: Row(children: [GestureDetector(onTap: () => Navigator.pop(context), child: const Icon(Icons.arrow_back_ios_new, size: 22)), const SizedBox(width: 14), const CircleAvatar(radius: 22, backgroundColor: Color(0xFFE4E8ED)), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(circle.name, style: const TextStyle(fontSize: 17, color: AppColors.textDark)), Text('${circle.members} members', style: const TextStyle(fontSize: 12, color: Color(0xFF80909A)))])), _circleHeaderIcon(Icons.notifications_none, badge: true), const SizedBox(width: 8), GestureDetector(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CircleSettingsScreen(circle: circle))), child: _circleHeaderIcon(Icons.settings_outlined))])) ,
        Expanded(child: ListView(padding: const EdgeInsets.fromLTRB(20, 0, 20, 24), children: [
          Row(children: [const Expanded(child: Text('Members', style: TextStyle(fontSize: 20, color: AppColors.textDark))), TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AllMembersScreen())), child: const Text('View Members ›', style: TextStyle(color: AppColors.primaryBlue, fontSize: 14)))]),
          const SizedBox(height: 2),
          SizedBox(height: 78, child: ListView(scrollDirection: Axis.horizontal, children: [for (int i=0;i<5;i++) Padding(padding: const EdgeInsets.only(right: 16), child: Column(children: [const CircleAvatar(radius: 22, backgroundColor: Color(0xFFE5E9ED)), const SizedBox(height: 6), Text(i==0?'You':'@user${i}', style: const TextStyle(fontSize: 10, color: Color(0xFF75858E)))])), Padding(padding: const EdgeInsets.only(right: 8), child: Column(children: [Container(width: 44,height:44, decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFFEAF6FF), border: Border.all(color: AppColors.primaryBlue)), child: const Center(child: Text('+2', style: TextStyle(color: AppColors.primaryBlue)))), const SizedBox(height: 6), const Text('More', style: TextStyle(fontSize: 10, color: AppColors.primaryBlue))]))]),
          const SizedBox(height: 14),
          GestureDetector(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CircleChatScreen(circle: circle))), child: Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: const Color(0xFFEAF7FF), borderRadius: BorderRadius.circular(20), border: Border.all(color: const Color(0xFFBBE2FA))), child: Row(children: [Container(width: 52, height:52, decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white, border: Border.all(color: const Color(0xFFB7E1FF))), child: const Icon(Icons.forum_outlined, color: AppColors.primaryBlue)), const SizedBox(width: 14), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Circle Chat', style: TextStyle(fontSize: 19, color: AppColors.textDark)), SizedBox(height: 4), Text('Aarav: Good workout today!', style: TextStyle(fontSize: 14, color: Color(0xFF6B7B84))), SizedBox(height: 3), Text('5 unread messages', style: TextStyle(fontSize: 13, color: AppColors.primaryBlue))])), const Icon(Icons.chevron_right, size: 28)]))),
          const SizedBox(height: 22),
          Container(padding: const EdgeInsets.fromLTRB(18, 18, 18, 12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(22), boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 16, offset: const Offset(0,4))]), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [const Expanded(child: Text('Recent Updates', style: TextStyle(fontSize: 19, color: AppColors.textDark))), TextButton(onPressed: () {}, child: const Text('View All', style: TextStyle(color: AppColors.primaryBlue)))]), _updateRow('You completed your hydr...', '2.5 L / 2.5 L', '1h ago'), _updateRow('@priya updated nutrition.', 'Meal logged', '3h ago'), _updateRow('@aarav12 updated sleep.', '8h 02m sleep', 'Yesterday')]))
        ])),
      ])),
      bottomNavigationBar: const _SubpageBottomNav(),
    );
  }
  static Widget _circleHeaderIcon(IconData icon,{bool badge=false})=>Container(width:44,height:44,decoration:const BoxDecoration(shape:BoxShape.circle,color:Color(0xFFF1F2F5)),child:Stack(alignment:Alignment.center,children:[Icon(icon,size:23,color:Color(0xFF4A565C)),if(badge) const Positioned(right:9,top:9,child:CircleAvatar(radius:3,color:Colors.red))]));
  static Widget _updateRow(String title,String sub,String time)=>Padding(padding:const EdgeInsets.symmetric(vertical:10),child:Row(children:[const CircleAvatar(radius:21,backgroundColor:Color(0xFFE5E9ED)),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:14,color:AppColors.textDark)),Text(sub,style:const TextStyle(fontSize:12,color:AppColors.primaryBlue))])),Text(time,style:const TextStyle(fontSize:12,color:Color(0xFF7B8A93))]));
}



class CircleSettingsScreen extends StatelessWidget {
  final _Circle circle;
  const CircleSettingsScreen({super.key, required this.circle});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 10),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: const Icon(Icons.arrow_back_ios_new, size: 22),
                  ),
                  Expanded(
                    child: Center(
                      child: Text(
                        'Settings',
                        style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w500, color: AppColors.textDark),
                      ),
                    ),
                  ),
                  const SizedBox(width: 22),
                ],
              ),
            ),
            const SizedBox(height: 8),
            GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CircleAppearanceScreen(circle: circle))),
              child: Column(
                children: [
                  Container(
                    width: 96,
                    height: 96,
                    decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFFDCE7FF)),
                    child: const Icon(Icons.groups, size: 48, color: Color(0xFF0C64C8)),
                  ),
                  const SizedBox(height: 14),
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text(circle.name, style: const TextStyle(fontSize: 24, color: AppColors.textDark)),
                    const SizedBox(width: 6),
                    const Icon(Icons.edit_outlined, size: 20, color: AppColors.textDark),
                  ]),
                  const SizedBox(height: 4),
                  Text('Created by you • ${circle.members} members', style: const TextStyle(fontSize: 14, color: Color(0xFF8AA0AF))),
                ],
              ),
            ),
            const SizedBox(height: 22),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 30),
                children: [
                  _settingsTile(context, Icons.people_outline, 'Manage Members', () => Navigator.push(context, MaterialPageRoute(builder: (_) => ManageCircleMembersScreen(circle: circle)))),
                  _settingsTile(context, Icons.person_add_alt_1_outlined, 'Add Members', () => Navigator.push(context, MaterialPageRoute(builder: (_) => AddMembersScreen(connections: const [
                    _Person('@priya.singh', 'Last active today'),
                    _Person('@aarav.1234', 'Last active yesterday'),
                    _Person('@rohan.ab', 'Last active 3 days ago'),
                    _Person('@meera.12', 'Last active 1 week ago'),
                  ])))),
                  _settingsTile(context, Icons.share_outlined, 'Your Shared Avatars', () => Navigator.push(context, MaterialPageRoute(builder: (_) => SharedAvatarSettingsScreen(circle: circle)))),
                  _settingsTile(context, Icons.notifications_none, 'Notifications', () => Navigator.push(context, MaterialPageRoute(builder: (_) => CircleNotificationSettingsScreen(circle: circle)))),
                  const SizedBox(height: 30),
                  _settingsTile(context, Icons.logout, 'Leave ${circle.name}', () => _confirmLeave(context), destructive: true),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: const _SubpageBottomNav(),
    );
  }

  Widget _settingsTile(BuildContext context, IconData icon, String title, VoidCallback onTap, {bool destructive = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.white,
        child: InkWell(
          borderRadius: BorderRadius.circular(13),
          onTap: onTap,
          child: Container(
            height: 64,
            padding: const EdgeInsets.symmetric(horizontal: 18),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(13),
              border: Border.all(color: const Color(0xFFB8D7F2)),
            ),
            child: Row(
              children: [
                Icon(icon, size: 30, color: destructive ? const Color(0xFFD21F3C) : const Color(0xFF627987)),
                const SizedBox(width: 18),
                Expanded(child: Text(title, style: TextStyle(fontSize: 15, color: destructive ? const Color(0xFFD21F3C) : Colors.black87))),
                Icon(Icons.chevron_right, size: 28, color: destructive ? const Color(0xFFD21F3C) : const Color(0xFF68767F)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _confirmLeave(BuildContext context) async {
    final leave = await showDialog<bool>(
      context: context,
      barrierColor: Colors.black26,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        title: const Text('Leave this circle?', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500)),
        content: const Text('You will no longer be able to see this circle’s chat or shared health updates.', style: TextStyle(fontSize: 15, height: 1.45, color: Color(0xFF71838C))),
        actionsPadding: const EdgeInsets.fromLTRB(18, 0, 18, 20),
        actions: [
          OutlinedButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Leave', style: TextStyle(color: Color(0xFFD21F3C)))),
        ],
      ),
    );
    if (leave == true && context.mounted) {
      Navigator.pop(context, true);
    }
  }
}

class ManageCircleMembersScreen extends StatefulWidget {
  final _Circle circle;
  const ManageCircleMembersScreen({super.key, required this.circle});
  @override State<ManageCircleMembersScreen> createState() => _ManageCircleMembersScreenState();
}

class _ManageCircleMembersScreenState extends State<ManageCircleMembersScreen> {
  final _search = TextEditingController();
  String _query = '';
  final List<_Person> _members = const [
    _Person('@priya.singh', 'Joined since 5 days'),
    _Person('@priya.singh1', 'Joined since 5 days'),
    _Person('@priya.singh2', 'Joined since 5 days'),
    _Person('@priya.singh3', 'Joined since 5 days'),
  ];
  @override void dispose(){_search.dispose();super.dispose();}
  @override Widget build(BuildContext context){
    final filtered=_members.where((p)=>_query.isEmpty||p.username.contains(_query.toLowerCase())).toList();
    return Scaffold(backgroundColor:Colors.white,body:SafeArea(bottom:false,child:Column(children:[
      Padding(padding:const EdgeInsets.fromLTRB(24,24,24,12),child:Row(children:[GestureDetector(onTap:()=>Navigator.pop(context),child:const Icon(Icons.arrow_back_ios_new,size:22)),const Expanded(child:Center(child:Text('Manage Members',style:TextStyle(fontSize:24,fontWeight:FontWeight.w500,color:AppColors.textDark)))),const SizedBox(width:22)])),
      Padding(padding:const EdgeInsets.symmetric(horizontal:20),child:TextField(controller:_search,onChanged:(v)=>setState(()=>_query=v.trim().toLowerCase()),decoration:const InputDecoration(hintText:'Search by username',prefixIcon:Icon(Icons.search),enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.all(Radius.circular(12)),borderSide:BorderSide(color:Color(0xFF9FB0B8))),focusedBorder:OutlineInputBorder(borderRadius:BorderRadius.all(Radius.circular(12)),borderSide:BorderSide(color:AppColors.primaryBlue))))),
      Expanded(child:ListView(padding:const EdgeInsets.fromLTRB(20,12,20,24),children:[
        const Text('Admins',style:TextStyle(color:Color(0xFF8BA1AD))),
        _adminCard(),
        const SizedBox(height:14),
        const Text('Members',style:TextStyle(color:Color(0xFF8BA1AD))),
        ...filtered.map((p)=>_managedMemberCard(p)),
        const SizedBox(height:12),
        const Text('Invited(1)',style:TextStyle(color:Color(0xFF8BA1AD))),
        _simpleCard('@riya','Invited'),
      ])),
    ])),bottomNavigationBar:const _SubpageBottomNav());
  }
  Widget _adminCard()=>_simpleCard('@sahil.123','Circle Admin');
  Widget _simpleCard(String user,String sub)=>Container(margin:const EdgeInsets.symmetric(vertical:7),padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(16),boxShadow:[BoxShadow(color:Colors.black.withValues(alpha:.05),blurRadius:12)]),child:Row(children:[const CircleAvatar(radius:28,backgroundColor:Color(0xFFE5E9ED)),const SizedBox(width:16),Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(user,style:const TextStyle(fontSize:18,color:AppColors.textDark)),Text(sub,style:const TextStyle(fontSize:14,color:Color(0xFF7D8E97)))])]));
  Widget _managedMemberCard(_Person p)=>GestureDetector(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>CircleMemberScreen(username:p.username))),child:Container(margin:const EdgeInsets.symmetric(vertical:7),padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(16),boxShadow:[BoxShadow(color:Colors.black.withValues(alpha:.05),blurRadius:12)]),child:Row(children:[const CircleAvatar(radius:28,backgroundColor:Color(0xFFE5E9ED)),const SizedBox(width:16),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(p.username,style:const TextStyle(fontSize:18,color:AppColors.textDark)),Text(p.activity,style:const TextStyle(fontSize:14,color:Color(0xFF7D8E97)))])),const Icon(Icons.chevron_right,color:Color(0xFF6D7A82))]));
}

class CircleMemberScreen extends StatelessWidget {
  final String username;
  const CircleMemberScreen({super.key, required this.username});
  @override Widget build(BuildContext context){
    return Scaffold(backgroundColor:Colors.white,body:SafeArea(bottom:false,child:Column(children:[
      Padding(padding:const EdgeInsets.fromLTRB(24,24,24,10),child:Row(children:[GestureDetector(onTap:()=>Navigator.pop(context),child:const Icon(Icons.arrow_back_ios_new,size:22)),const Expanded(child:Center(child:Text('Member',style:TextStyle(fontSize:24,fontWeight:FontWeight.w500,color:AppColors.textDark)))),const SizedBox(width:22)])),
      const SizedBox(height:25),
      const CircleAvatar(radius:48,backgroundColor:Color(0xFFE5E9ED)),
      const SizedBox(height:15),Text(username.replaceFirst('@','').split('.').map((e)=>e.isEmpty?'':e[0].toUpperCase()+e.substring(1)).join(' '),style:const TextStyle(fontSize:24,color:AppColors.textDark)),
      Text(username,style:const TextStyle(fontSize:14,color:Color(0xFF8AA0AF))),
      const SizedBox(height:25),
      _actionTile(context,Icons.person_outline,'View Profile',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>MemberAvatarScreen(username:username)))),
      _actionTile(context,Icons.share_outlined,'View Shared Avatars',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>MemberAvatarScreen(username:username)))),
      const Spacer(),
      _actionTile(context,Icons.delete_outline,'Remove from circle',(){showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('Remove from circle?'),content:Text('$username will no longer be able to access this circle.'),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),TextButton(onPressed:(){Navigator.pop(context);Navigator.pop(context);},child:const Text('Remove',style:TextStyle(color:Color(0xFFD21F3C))))]));},destructive:true),
      const SizedBox(height:20),
    ])),bottomNavigationBar:const _SubpageBottomNav());
  }
  Widget _actionTile(BuildContext context,IconData icon,String title,VoidCallback onTap,{bool destructive=false})=>Padding(padding:const EdgeInsets.fromLTRB(20,8,20,0),child:GestureDetector(onTap:onTap,child:Container(height:64,padding:const EdgeInsets.symmetric(horizontal:18),decoration:BoxDecoration(borderRadius:BorderRadius.circular(13),border:Border.all(color:const Color(0xFFB8D7F2))),child:Row(children:[Icon(icon,size:29,color:destructive?const Color(0xFFD21F3C):const Color(0xFF637984)),const SizedBox(width:18),Expanded(child:Text(title,style:TextStyle(color:destructive?const Color(0xFFD21F3C):Colors.black87,fontSize:15))),Icon(Icons.chevron_right,size:27,color:destructive?const Color(0xFFD21F3C):const Color(0xFF6D7A82))]))));
}

class SharedAvatarSettingsScreen extends StatefulWidget {
  final _Circle circle;
  const SharedAvatarSettingsScreen({super.key, required this.circle});
  @override State<SharedAvatarSettingsScreen> createState()=>_SharedAvatarSettingsScreenState();
}
class _SharedAvatarSettingsScreenState extends State<SharedAvatarSettingsScreen>{
  bool hydration=true,nutrition=true,sleep=false;
  @override Widget build(BuildContext context){return Scaffold(backgroundColor:Colors.white,body:SafeArea(bottom:false,child:Column(children:[
    Padding(padding:const EdgeInsets.fromLTRB(24,24,24,10),child:Row(children:[GestureDetector(onTap:()=>Navigator.pop(context),child:const Icon(Icons.arrow_back_ios_new,size:22)),const Expanded(child:Center(child:Text('Your Shared Avatars',style:TextStyle(fontSize:24,fontWeight:FontWeight.w500,color:AppColors.textDark)))),const SizedBox(width:22)])),
    const SizedBox(height:28),
    const Padding(padding:EdgeInsets.symmetric(horizontal:26),child:Text('Choose which health avatars are shared with circle members.',textAlign:TextAlign.center,style:TextStyle(fontSize:15,height:1.4,color:Color(0xFF71838C)))),
    const SizedBox(height:28),
    _row('💧','Hydration',hydration,(v)=>setState(()=>hydration=v)),
    _row('🍽️','Nutrition',nutrition,(v)=>setState(()=>nutrition=v)),
    Row(children:[const SizedBox(width:28),const Text('😴',style:TextStyle(fontSize:24)),const SizedBox(width:10),const Expanded(child:Text('Sleep',style:TextStyle(fontSize:20,color:AppColors.textDark))),_star(),const SizedBox(width:8),Switch(value:sleep,onChanged:(v)=>setState(()=>sleep=v),activeColor:Colors.white,activeTrackColor:AppColors.primaryBlue),const SizedBox(width:22)]),
    const Spacer(),
    SizedBox(width:212,child:ElevatedButton(onPressed:()=>Navigator.pop(context),child:const Text('Save Changes'))),const SizedBox(height:24),
  ])),bottomNavigationBar:const _SubpageBottomNav());}
  Widget _row(String e,String t,bool v,ValueChanged<bool> c)=>Row(children:[const SizedBox(width:28),Text(e,style:const TextStyle(fontSize:24)),const SizedBox(width:10),Expanded(child:Text(t,style:const TextStyle(fontSize:20,color:AppColors.textDark))),Switch(value:v,onChanged:c,activeColor:Colors.white,activeTrackColor:AppColors.primaryBlue),const SizedBox(width:22)]);
  Widget _star()=>Container(padding:const EdgeInsets.symmetric(horizontal:6,vertical:2),decoration:BoxDecoration(color:const Color(0xFFF3E6FF),border:Border.all(color:const Color(0xFF8B5CF6)),borderRadius:BorderRadius.circular(5)),child:const Text('🔒STAR',style:TextStyle(fontSize:10,color:Color(0xFF7C3AED))));
}

class CircleNotificationSettingsScreen extends StatefulWidget{
  final _Circle circle;
  const CircleNotificationSettingsScreen({super.key,required this.circle});
  @override State<CircleNotificationSettingsScreen> createState()=>_CircleNotificationSettingsScreenState();
}
class _CircleNotificationSettingsScreenState extends State<CircleNotificationSettingsScreen>{
  bool joins=true,updates=true,goals=true,avatars=true,mentions=true,messages=true;
  @override Widget build(BuildContext context){return Scaffold(backgroundColor:Colors.white,body:SafeArea(bottom:false,child:Column(children:[
    Padding(padding:const EdgeInsets.fromLTRB(24,24,24,10),child:Row(children:[GestureDetector(onTap:()=>Navigator.pop(context),child:const Icon(Icons.arrow_back_ios_new,size:22)),const Expanded(child:Center(child:Text('Notification Settings',style:TextStyle(fontSize:24,fontWeight:FontWeight.w500,color:AppColors.textDark)))),const SizedBox(width:22)])),
    const SizedBox(height:22),const Padding(padding:EdgeInsets.symmetric(horizontal:36),child:Text('Manage what notifications you receive from your circle.',textAlign:TextAlign.center,style:TextStyle(fontSize:15,height:1.4,color:Color(0xFF71838C)))),
    Expanded(child:ListView(padding:const EdgeInsets.fromLTRB(20,28,20,30),children:[
      _section('Circle Activity',[_switch('Member joins or leaves','Get notified when members join or leave this circle.',joins,(v)=>setState(()=>joins=v)),_switch('Circle updates','Stay informed about important circle changes.',updates,(v)=>setState(()=>updates=v))]),
      _section('Avatar updates',[_switch('Goal completions','Celebrate members reaching their health goals.',goals,(v)=>setState(()=>goals=v)),_switch('Avatar updates','Know when shared information is updated.',avatars,(v)=>setState(()=>avatars=v))]),
      _section('Chat',[_switch('Mentions','Get notified if someone mentions you in chat.',mentions,(v)=>setState(()=>mentions=v)),_switch('New Message','Stay up to date with new messages in chats.',messages,(v)=>setState(()=>messages=v))]),
    ]))
  ])),bottomNavigationBar:const _SubpageBottomNav());}
  Widget _section(String title,List<Widget> rows)=>Padding(padding:const EdgeInsets.only(bottom:22),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:15,color:Color(0xFF8EA4B1))),const SizedBox(height:10),Container(decoration:BoxDecoration(borderRadius:BorderRadius.circular(18),border:Border.all(color:const Color(0xFFF0F2F4))),child:Column(children:rows))]));
  Widget _switch(String title,String sub,bool v,ValueChanged<bool> c)=>Container(padding:const EdgeInsets.fromLTRB(16,14,14,12),decoration:const BoxDecoration(border:Border(bottom:BorderSide(color:Color(0xFFF1F2F4)))),child:Row(children:[Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:16,color:Color(0xFF3F4D55))),const SizedBox(height:2),Text(sub,style:const TextStyle(fontSize:12,color:Color(0xFF9BB0BE)))])),Switch(value:v,onChanged:c,activeColor:Colors.white,activeTrackColor:AppColors.primaryBlue),]));
}

class CircleAppearanceScreen extends StatefulWidget{
  final _Circle circle;
  const CircleAppearanceScreen({super.key,required this.circle});
  @override State<CircleAppearanceScreen> createState()=>_CircleAppearanceScreenState();
}
class _CircleAppearanceScreenState extends State<CircleAppearanceScreen>{
  late TextEditingController _name;
  int selected=0;
  @override void initState(){super.initState();_name=TextEditingController(text:widget.circle.name);}
  @override void dispose(){_name.dispose();super.dispose();}
  @override Widget build(BuildContext context){return Scaffold(backgroundColor:Colors.white,body:SafeArea(bottom:false,child:Column(children:[
    Padding(padding:const EdgeInsets.fromLTRB(24,24,24,10),child:Row(children:[GestureDetector(onTap:()=>Navigator.pop(context),child:const Icon(Icons.arrow_back_ios_new,size:22)),const Expanded(child:Center(child:Text('Profile',style:TextStyle(fontSize:24,fontWeight:FontWeight.w500,color:AppColors.textDark)))),const SizedBox(width:22)])),
    const SizedBox(height:24),Container(width:96,height:96,decoration:const BoxDecoration(shape:BoxShape.circle,color:Color(0xFFDCE7FF)),child:const Icon(Icons.groups,size:48,color:Color(0xFF0C64C8))),
    const SizedBox(height:26),const Align(alignment:Alignment.centerLeft,child:Padding(padding:EdgeInsets.only(left:28),child:Text('SELECT WALLPAPER',style:TextStyle(fontSize:14,color:Color(0xFF8EA4B1))))),
    const SizedBox(height:14),Padding(padding:const EdgeInsets.symmetric(horizontal:28),child:GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:4,crossAxisSpacing:18,mainAxisSpacing:18),itemCount:8,itemBuilder:(context,i)=>GestureDetector(onTap:()=>setState(()=>selected=i),child:Container(decoration:BoxDecoration(shape:BoxShape.circle,color:[const Color(0xFFE8EEF9),const Color(0xFFEAF7FF),const Color(0xFFF4EAFE),const Color(0xFFFFF0E8),const Color(0xFFE8F5EC),const Color(0xFFFFEEF4),const Color(0xFFEDE9FE),const Color(0xFFF0F4F7)][i],border:selected==i?Border.all(color:AppColors.primaryBlue,width:2):null))))),
    const SizedBox(height:48),const Align(alignment:Alignment.centerLeft,child:Padding(padding:EdgeInsets.only(left:28),child:Text('CIRCLE NAME',style:TextStyle(fontSize:14,color:Color(0xFF8EA4B1))))),
    const SizedBox(height:10),Padding(padding:const EdgeInsets.symmetric(horizontal:20),child:TextField(controller:_name,decoration:const InputDecoration(enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.all(Radius.circular(12)),borderSide:BorderSide(color:Color(0xFF8197A4))),focusedBorder:OutlineInputBorder(borderRadius:BorderRadius.all(Radius.circular(12)),borderSide:BorderSide(color:AppColors.primaryBlue)),contentPadding:EdgeInsets.symmetric(horizontal:16,vertical:16)))),
    const Spacer(),SizedBox(width:212,child:ElevatedButton(onPressed:()=>Navigator.pop(context),child:const Text('Save Changes'))),const SizedBox(height:24),
  ])),bottomNavigationBar:const _SubpageBottomNav());}
}

class CircleChatScreen extends StatefulWidget {
  final _Circle circle;
  const CircleChatScreen({super.key, required this.circle});
  @override State<CircleChatScreen> createState()=>_CircleChatScreenState();
}
class _CircleChatScreenState extends State<CircleChatScreen>{
  final _controller=TextEditingController();
  final List<Map<String,String>> messages=[
    {'user':'@aarav.1234','text':'Good workout today! 💪','time':'10:30 AM','mine':'0'},
    {'user':'@priya.singh','text':'Good workout today!','time':'10:30 AM','mine':'0'},
    {'user':'You','text':'Yes! Feeling great after that session 🔥','time':'10:32 AM','mine':'1'},
  ];
  @override void dispose(){_controller.dispose();super.dispose();}
  @override Widget build(BuildContext context){return Scaffold(backgroundColor:Colors.white,body:SafeArea(bottom:false,child:Column(children:[Padding(padding:const EdgeInsets.fromLTRB(20,22,20,8),child:Row(children:[GestureDetector(onTap:()=>Navigator.pop(context),child:const Icon(Icons.arrow_back_ios_new,size:22)),const SizedBox(width:14),const CircleAvatar(radius:22,backgroundColor:Color(0xFFE4E8ED)),const SizedBox(width:10),Expanded(child:Text(widget.circle.name,style:const TextStyle(fontSize:17,color:AppColors.textDark))),])),const Center(child:Padding(padding:EdgeInsets.symmetric(vertical:10),child:Chip(label:Text('Today')))),Expanded(child:ListView(padding:const EdgeInsets.symmetric(horizontal:20),children:messages.map((m)=>Align(alignment:m['mine']=='1'?Alignment.centerRight:Alignment.centerLeft,child:Padding(padding:const EdgeInsets.only(bottom:22),child:Row(mainAxisAlignment:m['mine']=='1'?MainAxisAlignment.end:MainAxisAlignment.start,crossAxisAlignment:CrossAxisAlignment.start,children:[if(m['mine']!='1') const CircleAvatar(radius:16,backgroundColor:Color(0xFFE5E9ED)),if(m['mine']!='1') const SizedBox(width:8),Flexible(child:Container(padding:const EdgeInsets.all(14),constraints:const BoxConstraints(maxWidth:260),decoration:BoxDecoration(color:m['mine']=='1'?AppColors.primaryBlue:Colors.white,border:Border.all(color:const Color(0xFFD8E7EF)),borderRadius:BorderRadius.only(topLeft:const Radius.circular(18),topRight:const Radius.circular(18),bottomLeft:Radius.circular(m['mine']=='1'?18:4),bottomRight:Radius.circular(m['mine']=='1'?4:18))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[if(m['mine']!='1') Text(m['user']!,style:const TextStyle(fontSize:11,color:Color(0xFF7E8D96)),),if(m['mine']!='1') const SizedBox(height:6),Text(m['text']!,style:TextStyle(fontSize:15,color:m['mine']=='1'?Colors.white:AppColors.textDark)),const SizedBox(height:4),Align(alignment:Alignment.bottomRight,child:Text(m['time']!,style:TextStyle(fontSize:9,color:m['mine']=='1'?Colors.white70:const Color(0xFFAAB6BE))))])))]))),).toList())),Padding(padding:const EdgeInsets.fromLTRB(28,8,28,18),child:Container(padding:const EdgeInsets.symmetric(horizontal:18),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(28),boxShadow:[BoxShadow(color:Colors.black.withValues(alpha:0.12),blurRadius:16)]),child:Row(children:[Expanded(child:TextField(controller:_controller,decoration:const InputDecoration(hintText:'Type here..',border:InputBorder.none))),const Icon(Icons.mic_none,color:Color(0xFF78909C)),IconButton(onPressed:()=>setState((){final t=_controller.text.trim();if(t.isNotEmpty){messages.add({'user':'You','text':t,'time':'Now','mine':'1'});_controller.clear();}}),icon:const Icon(Icons.send_outlined,color:AppColors.primaryBlue))])))])),bottomNavigationBar:const _SubpageBottomNav());}
}

class AllMembersScreen extends StatelessWidget{
  @override Widget build(BuildContext context){final users=['@sahil.123','@priya.singh','@priya.singh','@priya.singh','@priya.singh','@riya'];return Scaffold(backgroundColor:Colors.white,body:SafeArea(bottom:false,child:Column(children:[Padding(padding:const EdgeInsets.fromLTRB(24,24,24,12),child:Row(children:[GestureDetector(onTap:()=>Navigator.pop(context),child:const Icon(Icons.arrow_back_ios_new,size:22)),const Expanded(child:Center(child:Text('All Members',style:TextStyle(fontSize:24,fontWeight:FontWeight.w500,color:AppColors.textDark)))),const SizedBox(width:22)])),Padding(padding:const EdgeInsets.symmetric(horizontal:20),child:TextField(decoration:const InputDecoration(hintText:'Search by username',prefixIcon:Icon(Icons.search),enabledBorder:OutlineInputBorder(borderRadius:BorderRadius.all(Radius.circular(12)),borderSide:BorderSide(color:Color(0xFF9FB0B8))),focusedBorder:OutlineInputBorder(borderRadius:BorderRadius.all(Radius.circular(12)),borderSide:BorderSide(color:AppColors.primaryBlue))))),Expanded(child:ListView(padding:const EdgeInsets.fromLTRB(20,10,20,20),children:[const Text('Admins',style:TextStyle(color:Color(0xFF8BA1AD))),_memberCard('@sahil.123','Circle Admin',tap:true),const SizedBox(height:16),const Text('Members',style:TextStyle(color:Color(0xFF8BA1AD)),),...users.skip(1).map((u)=>_memberCard(u,'Joined since 5 days',tap:true)),const SizedBox(height:10),const Text('Invited(1)',style:TextStyle(color:Color(0xFF8BA1AD))),_memberCard('@riya','Invited',tap:false),const SizedBox(height:10),Center(child:SizedBox(width:212,child:ElevatedButton(onPressed:(){},child:const Row(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(Icons.add_circle_outline),SizedBox(width:8),Text('Add Members')]))))]))])),bottomNavigationBar:const _SubpageBottomNav());}
  Widget _memberCard(String user,String sub,{required bool tap})=>GestureDetector(onTap:tap?()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>MemberAvatarScreen(username:user)):null,child:Container(margin:const EdgeInsets.symmetric(vertical:7),padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(16),boxShadow:[BoxShadow(color:Colors.black.withValues(alpha:0.05),blurRadius:12)]),child:Row(children:[const CircleAvatar(radius:28,backgroundColor:Color(0xFFE5E9ED)),const SizedBox(width:16),Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(user,style:const TextStyle(fontSize:18,color:AppColors.textDark)),Text(sub,style:const TextStyle(fontSize:14,color:Color(0xFF7D8E97)))])])));
}

class MemberAvatarScreen extends StatefulWidget{final String username;const MemberAvatarScreen({super.key,required this.username});@override State<MemberAvatarScreen> createState()=>_MemberAvatarScreenState();}
class _MemberAvatarScreenState extends State<MemberAvatarScreen>{int page=0;@override Widget build(BuildContext context){return Scaffold(backgroundColor:Colors.white,body:SafeArea(bottom:false,child:Column(children:[Padding(padding:const EdgeInsets.fromLTRB(28,24,20,10),child:Row(children:[GestureDetector(onTap:()=>Navigator.pop(context),child:const Icon(Icons.arrow_back_ios_new,size:22)),const SizedBox(width:18),Expanded(child:Text(widget.username,style:const TextStyle(fontSize:24,color:AppColors.textDark))),OutlinedButton(onPressed:(){},child:const Text('View Profile'))])),Expanded(child:PageView(controller:PageController(initialPage:page),onPageChanged:(i)=>setState(()=>page=i),children:[_avatarPage('💧 Water','2.1 L','84%','Water',unlocked:true),_avatarPage('🍽️ Meal','','','Meal',unlocked:false,lockedText:'This member has not shared\ntheir nutrition avatar.'),_avatarPage('😴 Sleep','','','Sleep',unlocked:false,lockedText:'Sleep avatar is available with STAR plan.')]))])) ,bottomNavigationBar:const _SubpageBottomNav());}
  Widget _avatarPage(String title,String value,String percent,String kind,{required bool unlocked,String? lockedText})=>Stack(children:[Center(child:Image.asset('assets/images/avatar_male.png',width:300,height:520,fit:BoxFit.contain)),Positioned(left:20,top:50,child:Container(width:112,padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(14),boxShadow:[BoxShadow(color:Colors.black.withValues(alpha:0.1),blurRadius:16)]),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:14,color:AppColors.textDark)),const SizedBox(height:8),if(unlocked)...[Text(value,style:const TextStyle(fontSize:20,color:AppColors.primaryBlue)),Text('of 2.5 L goal',style:const TextStyle(fontSize:9,color:Color(0xFF9AABB3))),const SizedBox(height:4)],if(!unlocked) ...[const SizedBox(height:6),Text(lockedText!,style:const TextStyle(fontSize:10,height:1.35,color:Color(0xFF8797A0))),if(kind=='Sleep') ...[const SizedBox(height:8),OutlinedButton(onPressed:(){},child:const Text('Upgrade',style:TextStyle(fontSize:11,color:Color(0xFF6A4EB0))))]])),),Positioned(bottom:60,left:0,right:0,child:Row(mainAxisAlignment:MainAxisAlignment.center,children:[for(int i=0;i<3;i++)Container(width:i==page?8:8,height:8,margin:const EdgeInsets.symmetric(horizontal:4),decoration:BoxDecoration(shape:BoxShape.circle,color:i==page?AppColors.primaryBlue:const Color(0xFF9AAEB8)))])),Positioned(bottom:16,left:0,right:0,child:Center(child:Text('Last updated 1h ago',style:const TextStyle(fontSize:14,color:Color(0xFF7B8B93))))]);
}

class CircleInviteScreen extends StatelessWidget {
  final _CircleInvite invite;
  const CircleInviteScreen({super.key, required this.invite});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        bottom: false,
        child: Column(children: [
          const Spacer(flex: 2),
          Container(width: 110, height: 110, decoration: const BoxDecoration(color: Color(0xFFF1F6FF), shape: BoxShape.circle), child: const Icon(Icons.person_add_alt_1_outlined, size: 52, color: AppColors.primaryBlue)),
          const SizedBox(height: 54),
          const Text('You are invited to join', style: TextStyle(fontSize: 14, color: Color(0xFF7F8A90))),
          const SizedBox(height: 8),
          Text(invite.name, style: const TextStyle(fontSize: 24, color: AppColors.primaryBlue)),
          const SizedBox(height: 4),
          Text('Invited by ${invite.invitedBy}', style: const TextStyle(fontSize: 13, color: Color(0xFF67757D))),
          const SizedBox(height: 24),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [SizedBox(width: 96, child: Stack(children: List.generate(3, (i) => Positioned(left: i * 30.0, child: const CircleAvatar(radius: 20, backgroundColor: Color(0xFFE2E7EC))))))), const SizedBox(width: 18), Text('${invite.members} members', style: const TextStyle(fontSize: 15, color: Color(0xFF65737B)))]),
          const SizedBox(height: 34),
          Container(margin: const EdgeInsets.symmetric(horizontal: 40), padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 20), decoration: BoxDecoration(color: const Color(0xFFF1F6FF), borderRadius: BorderRadius.circular(16)), child: const Text('By joining, you can connect, chat and view shared health updates.', textAlign: TextAlign.center, style: TextStyle(fontSize: 15, height: 1.45, color: Color(0xFF7152A8)))),
          const Spacer(flex: 3),
          SizedBox(width: 212, child: ElevatedButton(onPressed: () => Navigator.pop(context), child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [Text('Join Circle'), SizedBox(width: 10), Icon(Icons.arrow_forward)]))),
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Decline', style: TextStyle(color: Color(0xFF7C858A), fontSize: 16))),
          const SizedBox(height: 22),
        ]),
      ),
      bottomNavigationBar: const _SubpageBottomNav(),
    );
  }
}

class _SubpageBottomNav extends StatelessWidget {
  const _SubpageBottomNav();

  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(color: Colors.black.withValues(alpha: 0.10), blurRadius: 8, offset: const Offset(0, -2)),
          ],
        ),
        child: SafeArea(
          top: false,
          child: SizedBox(
            height: 64,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _item(Icons.home_outlined, 'Home'),
                _item(Icons.groups_outlined, 'Care Circle', selected: true),
                _item(Icons.auto_awesome_outlined, 'Rin AI'),
                _item(Icons.person_outline, 'Profile'),
              ],
            ),
          ),
        ),
      );

  Widget _item(IconData icon, String label, {bool selected = false}) => Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 25, color: selected ? AppColors.primaryBlue : const Color(0xFF4A565C)),
          const SizedBox(height: 2),
          Text(label, style: TextStyle(fontSize: 10, color: selected ? AppColors.primaryBlue : const Color(0xFF4A565C))),
        ],
      );
}

class _Circle {
  final String name;
  final int members;
  final int updates;
  const _Circle(this.name, this.members, this.updates);
}

class _CircleInvite {
  final String name;
  final int members;
  final String invitedBy;
  const _CircleInvite(this.name, this.members, this.invitedBy);
}

class _Person {
  final String username;
  final String activity;
  const _Person(this.username, this.activity);
}
